--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6 (Debian 15.6-0+deb12u1)
-- Dumped by pg_dump version 15.6 (Debian 15.6-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pcreate;
--
-- Name: pcreate; Type: DATABASE; Schema: -; Owner: pcreate
--

CREATE DATABASE pcreate WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE pcreate OWNER TO pcreate;

\connect pcreate

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: articulo_carrito; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.articulo_carrito (
    articulo_id bigint NOT NULL,
    carrito_id bigint NOT NULL,
    cantidad integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.articulo_carrito OWNER TO pcreate;

--
-- Name: articulo_factura; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.articulo_factura (
    articulo_id bigint NOT NULL,
    factura_id bigint NOT NULL,
    cantidad integer DEFAULT 1 NOT NULL,
    precio numeric(10,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.articulo_factura OWNER TO pcreate;

--
-- Name: articulo_pc; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.articulo_pc (
    articulo_id bigint NOT NULL,
    pc_id bigint NOT NULL,
    cantidad integer DEFAULT 1 NOT NULL,
    parte character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.articulo_pc OWNER TO pcreate;

--
-- Name: articulos; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.articulos (
    id bigint NOT NULL,
    categoria_id bigint NOT NULL,
    marca_id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    precio numeric(8,2) NOT NULL,
    descripcion text NOT NULL,
    puntuacion integer DEFAULT 0 NOT NULL,
    "puntuacionPrecio" numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    datos json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.articulos OWNER TO pcreate;

--
-- Name: articulos_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.articulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articulos_id_seq OWNER TO pcreate;

--
-- Name: articulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.articulos_id_seq OWNED BY public.articulos.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO pcreate;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO pcreate;

--
-- Name: carritos; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.carritos (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.carritos OWNER TO pcreate;

--
-- Name: carritos_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.carritos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carritos_id_seq OWNER TO pcreate;

--
-- Name: carritos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.carritos_id_seq OWNED BY public.carritos.id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.categorias (
    id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.categorias OWNER TO pcreate;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.categorias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_id_seq OWNER TO pcreate;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: comentarios; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.comentarios (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    contenido text NOT NULL,
    estrellas integer NOT NULL,
    comentable_type character varying(255) NOT NULL,
    comentable_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.comentarios OWNER TO pcreate;

--
-- Name: comentarios_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.comentarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comentarios_id_seq OWNER TO pcreate;

--
-- Name: comentarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.comentarios_id_seq OWNED BY public.comentarios.id;


--
-- Name: domicilios; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.domicilios (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    provincia_id bigint NOT NULL,
    direccion character varying(255) NOT NULL,
    ciudad character varying(255) NOT NULL,
    telefono character varying(255) NOT NULL,
    cpostal integer NOT NULL,
    favorito boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.domicilios OWNER TO pcreate;

--
-- Name: domicilios_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.domicilios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.domicilios_id_seq OWNER TO pcreate;

--
-- Name: domicilios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.domicilios_id_seq OWNED BY public.domicilios.id;


--
-- Name: facturas; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.facturas (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    domicilio_id bigint NOT NULL,
    entrega_aproximada date DEFAULT '2024-06-08'::date NOT NULL,
    fecha_creacion date DEFAULT '2024-06-03'::date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.facturas OWNER TO pcreate;

--
-- Name: facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.facturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.facturas_id_seq OWNER TO pcreate;

--
-- Name: facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.facturas_id_seq OWNED BY public.facturas.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO pcreate;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO pcreate;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: fotos; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.fotos (
    id bigint NOT NULL,
    articulo_id bigint NOT NULL,
    orden integer NOT NULL,
    imagen character varying(255) DEFAULT 'default.png'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.fotos OWNER TO pcreate;

--
-- Name: fotos_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.fotos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fotos_id_seq OWNER TO pcreate;

--
-- Name: fotos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.fotos_id_seq OWNED BY public.fotos.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO pcreate;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO pcreate;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO pcreate;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: marcas; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.marcas (
    id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.marcas OWNER TO pcreate;

--
-- Name: marcas_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.marcas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marcas_id_seq OWNER TO pcreate;

--
-- Name: marcas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.marcas_id_seq OWNED BY public.marcas.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO pcreate;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO pcreate;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO pcreate;

--
-- Name: pcs; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.pcs (
    id bigint NOT NULL,
    socket_id bigint NOT NULL,
    user_id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    publicado boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.pcs OWNER TO pcreate;

--
-- Name: pcs_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.pcs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pcs_id_seq OWNER TO pcreate;

--
-- Name: pcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.pcs_id_seq OWNED BY public.pcs.id;


--
-- Name: provincias; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.provincias (
    id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.provincias OWNER TO pcreate;

--
-- Name: provincias_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.provincias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provincias_id_seq OWNER TO pcreate;

--
-- Name: provincias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.provincias_id_seq OWNED BY public.provincias.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO pcreate;

--
-- Name: sockets; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.sockets (
    id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    imagen character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.sockets OWNER TO pcreate;

--
-- Name: sockets_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.sockets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sockets_id_seq OWNER TO pcreate;

--
-- Name: sockets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.sockets_id_seq OWNED BY public.sockets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: pcreate
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    avatar character varying(255) DEFAULT 'default.png'::character varying NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    role character varying(255) DEFAULT 'user'::character varying NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO pcreate;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pcreate
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO pcreate;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcreate
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: articulos id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulos ALTER COLUMN id SET DEFAULT nextval('public.articulos_id_seq'::regclass);


--
-- Name: carritos id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.carritos ALTER COLUMN id SET DEFAULT nextval('public.carritos_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: comentarios id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.comentarios ALTER COLUMN id SET DEFAULT nextval('public.comentarios_id_seq'::regclass);


--
-- Name: domicilios id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.domicilios ALTER COLUMN id SET DEFAULT nextval('public.domicilios_id_seq'::regclass);


--
-- Name: facturas id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.facturas ALTER COLUMN id SET DEFAULT nextval('public.facturas_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: fotos id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.fotos ALTER COLUMN id SET DEFAULT nextval('public.fotos_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: marcas id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.marcas ALTER COLUMN id SET DEFAULT nextval('public.marcas_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: pcs id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.pcs ALTER COLUMN id SET DEFAULT nextval('public.pcs_id_seq'::regclass);


--
-- Name: provincias id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.provincias ALTER COLUMN id SET DEFAULT nextval('public.provincias_id_seq'::regclass);


--
-- Name: sockets id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.sockets ALTER COLUMN id SET DEFAULT nextval('public.sockets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: articulo_carrito; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.articulo_carrito (articulo_id, carrito_id, cantidad, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.articulo_carrito (articulo_id, carrito_id, cantidad, created_at, updated_at, deleted_at) FROM '$$PATH$$/3583.dat';

--
-- Data for Name: articulo_factura; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.articulo_factura (articulo_id, factura_id, cantidad, precio, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.articulo_factura (articulo_id, factura_id, cantidad, precio, created_at, updated_at, deleted_at) FROM '$$PATH$$/3578.dat';

--
-- Data for Name: articulo_pc; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.articulo_pc (articulo_id, pc_id, cantidad, parte, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.articulo_pc (articulo_id, pc_id, cantidad, parte, created_at, updated_at, deleted_at) FROM '$$PATH$$/3575.dat';

--
-- Data for Name: articulos; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.articulos (id, categoria_id, marca_id, nombre, precio, descripcion, puntuacion, "puntuacionPrecio", datos, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.articulos (id, categoria_id, marca_id, nombre, precio, descripcion, puntuacion, "puntuacionPrecio", datos, created_at, updated_at, deleted_at) FROM '$$PATH$$/3570.dat';

--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.cache (key, value, expiration) FROM stdin;
\.
COPY public.cache (key, value, expiration) FROM '$$PATH$$/3550.dat';

--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.
COPY public.cache_locks (key, owner, expiration) FROM '$$PATH$$/3551.dat';

--
-- Data for Name: carritos; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.carritos (id, user_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.carritos (id, user_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/3582.dat';

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.categorias (id, nombre, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.categorias (id, nombre, created_at, updated_at, deleted_at) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: comentarios; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.comentarios (id, user_id, contenido, estrellas, comentable_type, comentable_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.comentarios (id, user_id, contenido, estrellas, comentable_type, comentable_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/3580.dat';

--
-- Data for Name: domicilios; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.domicilios (id, user_id, nombre, provincia_id, direccion, ciudad, telefono, cpostal, favorito, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.domicilios (id, user_id, nombre, provincia_id, direccion, ciudad, telefono, cpostal, favorito, created_at, updated_at, deleted_at) FROM '$$PATH$$/3564.dat';

--
-- Data for Name: facturas; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.facturas (id, user_id, domicilio_id, entrega_aproximada, fecha_creacion, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.facturas (id, user_id, domicilio_id, entrega_aproximada, fecha_creacion, created_at, updated_at, deleted_at) FROM '$$PATH$$/3577.dat';

--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.
COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM '$$PATH$$/3556.dat';

--
-- Data for Name: fotos; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.fotos (id, articulo_id, orden, imagen, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.fotos (id, articulo_id, orden, imagen, created_at, updated_at, deleted_at) FROM '$$PATH$$/3574.dat';

--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.
COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM '$$PATH$$/3554.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.
COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM '$$PATH$$/3553.dat';

--
-- Data for Name: marcas; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.marcas (id, nombre, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.marcas (id, nombre, created_at, updated_at, deleted_at) FROM '$$PATH$$/3566.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/3547.dat';

--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.
COPY public.password_reset_tokens (email, token, created_at) FROM '$$PATH$$/3559.dat';

--
-- Data for Name: pcs; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.pcs (id, socket_id, user_id, nombre, publicado, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.pcs (id, socket_id, user_id, nombre, publicado, created_at, updated_at, deleted_at) FROM '$$PATH$$/3572.dat';

--
-- Data for Name: provincias; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.provincias (id, nombre, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.provincias (id, nombre, created_at, updated_at, deleted_at) FROM '$$PATH$$/3549.dat';

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.
COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM '$$PATH$$/3560.dat';

--
-- Data for Name: sockets; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.sockets (id, nombre, imagen, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.sockets (id, nombre, imagen, created_at, updated_at, deleted_at) FROM '$$PATH$$/3562.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pcreate
--

COPY public.users (id, name, avatar, email, email_verified_at, password, role, remember_token, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.users (id, name, avatar, email, email_verified_at, password, role, remember_token, created_at, updated_at, deleted_at) FROM '$$PATH$$/3558.dat';

--
-- Name: articulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.articulos_id_seq', 22, true);


--
-- Name: carritos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.carritos_id_seq', 2, true);


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.categorias_id_seq', 10, true);


--
-- Name: comentarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.comentarios_id_seq', 1, false);


--
-- Name: domicilios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.domicilios_id_seq', 1, false);


--
-- Name: facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.facturas_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: fotos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.fotos_id_seq', 88, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: marcas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.marcas_id_seq', 23, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.migrations_id_seq', 17, true);


--
-- Name: pcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.pcs_id_seq', 4, true);


--
-- Name: provincias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.provincias_id_seq', 52, true);


--
-- Name: sockets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.sockets_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcreate
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: articulo_carrito articulo_carrito_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_carrito
    ADD CONSTRAINT articulo_carrito_pkey PRIMARY KEY (articulo_id, carrito_id);


--
-- Name: articulo_factura articulo_factura_articulo_id_factura_id_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_factura
    ADD CONSTRAINT articulo_factura_articulo_id_factura_id_unique UNIQUE (articulo_id, factura_id);


--
-- Name: articulo_pc articulo_pc_articulo_id_pc_id_parte_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_pc
    ADD CONSTRAINT articulo_pc_articulo_id_pc_id_parte_unique UNIQUE (articulo_id, pc_id, parte);


--
-- Name: articulos articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: carritos carritos_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.carritos
    ADD CONSTRAINT carritos_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_nombre_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nombre_unique UNIQUE (nombre);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: comentarios comentarios_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.comentarios
    ADD CONSTRAINT comentarios_pkey PRIMARY KEY (id);


--
-- Name: domicilios domicilios_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.domicilios
    ADD CONSTRAINT domicilios_pkey PRIMARY KEY (id);


--
-- Name: facturas facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: fotos fotos_articulo_id_orden_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.fotos
    ADD CONSTRAINT fotos_articulo_id_orden_unique UNIQUE (articulo_id, orden);


--
-- Name: fotos fotos_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.fotos
    ADD CONSTRAINT fotos_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: marcas marcas_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.marcas
    ADD CONSTRAINT marcas_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: pcs pcs_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.pcs
    ADD CONSTRAINT pcs_pkey PRIMARY KEY (id);


--
-- Name: provincias provincias_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.provincias
    ADD CONSTRAINT provincias_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sockets sockets_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.sockets
    ADD CONSTRAINT sockets_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: comentarios_comentable_type_comentable_id_index; Type: INDEX; Schema: public; Owner: pcreate
--

CREATE INDEX comentarios_comentable_type_comentable_id_index ON public.comentarios USING btree (comentable_type, comentable_id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: pcreate
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: pcreate
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: pcreate
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: articulo_carrito articulo_carrito_articulo_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_carrito
    ADD CONSTRAINT articulo_carrito_articulo_id_foreign FOREIGN KEY (articulo_id) REFERENCES public.articulos(id) ON DELETE CASCADE;


--
-- Name: articulo_carrito articulo_carrito_carrito_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_carrito
    ADD CONSTRAINT articulo_carrito_carrito_id_foreign FOREIGN KEY (carrito_id) REFERENCES public.carritos(id) ON DELETE CASCADE;


--
-- Name: articulo_factura articulo_factura_articulo_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_factura
    ADD CONSTRAINT articulo_factura_articulo_id_foreign FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: articulo_factura articulo_factura_factura_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_factura
    ADD CONSTRAINT articulo_factura_factura_id_foreign FOREIGN KEY (factura_id) REFERENCES public.facturas(id);


--
-- Name: articulo_pc articulo_pc_articulo_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_pc
    ADD CONSTRAINT articulo_pc_articulo_id_foreign FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: articulo_pc articulo_pc_pc_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulo_pc
    ADD CONSTRAINT articulo_pc_pc_id_foreign FOREIGN KEY (pc_id) REFERENCES public.pcs(id);


--
-- Name: articulos articulos_categoria_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_categoria_id_foreign FOREIGN KEY (categoria_id) REFERENCES public.categorias(id);


--
-- Name: articulos articulos_marca_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_marca_id_foreign FOREIGN KEY (marca_id) REFERENCES public.marcas(id);


--
-- Name: carritos carritos_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.carritos
    ADD CONSTRAINT carritos_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: comentarios comentarios_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.comentarios
    ADD CONSTRAINT comentarios_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: domicilios domicilios_provincia_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.domicilios
    ADD CONSTRAINT domicilios_provincia_id_foreign FOREIGN KEY (provincia_id) REFERENCES public.provincias(id);


--
-- Name: domicilios domicilios_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.domicilios
    ADD CONSTRAINT domicilios_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: facturas facturas_domicilio_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_domicilio_id_foreign FOREIGN KEY (domicilio_id) REFERENCES public.domicilios(id);


--
-- Name: facturas facturas_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fotos fotos_articulo_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.fotos
    ADD CONSTRAINT fotos_articulo_id_foreign FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: pcs pcs_socket_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.pcs
    ADD CONSTRAINT pcs_socket_id_foreign FOREIGN KEY (socket_id) REFERENCES public.sockets(id);


--
-- Name: pcs pcs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: pcreate
--

ALTER TABLE ONLY public.pcs
    ADD CONSTRAINT pcs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

